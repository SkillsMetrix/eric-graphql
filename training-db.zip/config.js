export const MONGO_URL="mongodb+srv://ericuser:eric123@cluster0.rle5i.mongodb.net/ericdb?retryWrites=true&w=majority&appName=Cluster0"
export const JWT_SECRET ="somedummyname"