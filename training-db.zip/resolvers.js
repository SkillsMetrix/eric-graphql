
import mongoose from "mongoose";
import User from "./models/User.js";
import Quote from "./models/Quotes.js";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { JWT_SECRET } from "./config.js";
const resolvers = {
  Query: {
    users: async() => await User.find({}),
    quotes: async() => await Quote.find({}),

    user: async(_, { _id }) => await User.findOne({_id}),
    iquote: async(_, { by }) => await Quote.find({}).populate("by","_id firstName"),
  },
  User: {
    quotes: async(ur) => await Quote.find({by:ur._id}),
  },
  Mutation: {
    signupUser: async (_, { userNew }) => {
      const user = await User.findOne({ email: userNew.email });
      if (user) {
        throw new Error("User Already Exist with that Email...!");
      }
      const hp = await bcrypt.hash(userNew.password, 12);
      const newUser = new User({
        ...userNew,
        password: hp,
      });
      return await newUser.save();
    },
    signinUser: async (_, { userSignin }) => {
      const user = await User.findOne({ email: userSignin.email });
      if (!user) {
        throw new Error("User doesnt Exist with that Email...!");
      }
      const doMatch = await bcrypt.compare(userSignin.password, user.password);
      if (!doMatch) {
        throw new Error("Email or password is invalid");
      }
      const token = jwt.sign({ userId: user._id }, JWT_SECRET);
      return { token };
    },
    createQuote: async (_, { name }, { userId }) => {
      if (!userId) throw new Error("You Must Logged id");
      const newQuote = new Quote({
        name,
        by: userId,
      });
      await newQuote.save();
      return "Quote Saved Successfully...!";
    },
  },
};
export default resolvers;
