import { ApolloServer, gql } from "apollo-server";
import { ApolloServerPluginLandingPageGraphQLPlayground } from "apollo-server-core";

const typeDefs= gql`

enum MediaTypes{

    BOOK
    MOVIE
}
interface Media{
    id: ID
    title: String
    type: MediaTypes
}
type Book implements Media{
    id: ID
    title: String
    author: String
    type: MediaTypes

}
type Movie implements Media{
    id: ID
    title: String
    director: String
    type: MediaTypes

}
union SearchResult = Book | Movie

type Query {
    search(term: String) : [SearchResult]
    getBooks: [Book]
    getMovies: [Movie]
}
type Quote {
    name: String
    by: ID
}
`
const books= [
    {id:"1",title:"1987",author:"george",type:"BOOK"},
    {id:"2",title:"brave world",author:"Aldous",type:"BOOK"},
]
const movies= [
    {id:"1",title:"inception",director:"nolan",type:"MOVIE"},
    {id:"2",title:"the Matrix",director:"Lilly",type:"MOVIE"},
]
const resolvers={
    Query: {
        search:(_,{term}) =>{
            return [
                ...books.filter((book) => book.title.includes(term)),
                ...movies.filter((movie) => movie.title.includes(term))
            ]
        },
        getBooks:() => books,
        getMovies:() => movies
    },
    SearchResult:{
        __resolveType(obj){
            if(obj.author){
                return "Book"
            }
            if(obj.director){
                return "Movie"
            }
            return null
        }
    }
}
const server = new ApolloServer({
    typeDefs,
    resolvers,
    plugins: [ApolloServerPluginLandingPageGraphQLPlayground()],
  });
  
  server.listen().then(({ url }) => {
    console.log(`server is ready ${url}`);
  });